import React from 'react'

const Forgotpassword = () => {
  return (
    <div>F</div>
  )
}

export default Forgotpassword;