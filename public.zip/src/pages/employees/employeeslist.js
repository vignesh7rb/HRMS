import React from 'react'

const EmployeeList = () => {
  return (
    <div>employeeslist</div>
  )
}

export default EmployeeList;