import React from 'react'

const Trainings = () => {
  return (
    <div>trainings</div>
  )
}

export default Trainings;