import React from 'react'

const  Skills = () => {
  return (
    <div>skills</div>
  )
}

export default Skills;