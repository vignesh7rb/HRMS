import React from 'react';

const Footer = () => {
  return (
    <footer className="main-footer">
      © 2025 HRMS | All Rights Reserved
    </footer>
  );
};

export default Footer;
