import React from 'react'

const Protectedroute = () => {
  return (
    <div>protectedroute</div>
  )
}

export default Protectedroute;