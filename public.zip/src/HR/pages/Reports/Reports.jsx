const Reports = () => {
  return (
    <>
      <h1>Reports</h1>
      <div className="card">HR analytics & reports</div>
    </>
  );
};

export default Reports;
