import { combineReducers } from "@reduxjs/toolkit";



export const rootReducer = combineReducers({
  // companies: companyReducer, // ✅ add this

});

export default rootReducer;
