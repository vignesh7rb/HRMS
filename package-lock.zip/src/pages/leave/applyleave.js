import React from 'react'

const ApplyLeave = () => {
  return (
    <div>applyleave</div>
  )
}

export default ApplyLeave;