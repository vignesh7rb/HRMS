import React from 'react'

const EmployeeProfile = () => {
  return (
    <div>employeeprofile</div>
  )
}

export default EmployeeProfile;